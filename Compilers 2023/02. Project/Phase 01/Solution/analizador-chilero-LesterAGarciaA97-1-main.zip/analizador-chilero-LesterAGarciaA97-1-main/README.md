[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/oFR9BWk3)
Compilador CHILERO (primera fase)
=================================

Al iniciar la tarea, su repositorio debera contener los siguientes archivos y directorios importantes:

* Makefile
* README.md
* lexer-chilero
* lexer-chilero/src/main/java/gt/edu/url/compiler
* lexer-chilero/src/main/jflex
* cooltests

`Makefile` contiene objetivos para compilar y ejecutar su programa. NO MODIFICAR.

`README.md` contiene esta información. 

`lexer-chilero/src/main/jflex/simpletokenizer.lex` es un archivo esqueleto para la especificación del analizador léxico. Debera completarlo con expresiones, patrones y acciones.

Dentro de `cooltests` encontrará tres programas de prueba:

1. `test.cl` en el cual puede probar análisis léxico y recuperación de errores. Este programa NO es correcto y le puede servir para verificar que su analizador léxico detecte correctamente los errores. Así mismo debera modificarlo para que sea correcto.
2. `factloop.cl` es una calculadora de factorial.
3. `stack.cl` es una solución a la máquina de pila previamente elaborada en el laboratorio.

`lexer-chilero/src/main/java/gt/edu/url/TokenConstants.java` contiene definiciones de constantes que utilizan casi todas las partes del compilador. NO MODIFICAR.

`lexer-chilero/src/main/java/gt/edu/url/Table.java` y `lexer-chilero/src/main/java/gt/edu/url/Symbol.java` contienen tablas de cadenas y símbolos útiles en las siguientes fases del compilador NO MODIFICAR.

`lexer-chilero/src/main/java/gt/edu/url/Utilities.java` contiene varias funciones de soporte utilizadas por el controlador lexer principal (Lexer.java). NO MODIFICAR.

`mycoolc` es un script de shell que une las fases del compilador que utiliza pipes de Unix en lugar de vincular estáticamente el código.  Si bien es ineficiente, esta arquitectura facilita la combinación y combinación los componentes que escribe con los del compilador del curso. NO MODIFICAR.

Tareas principales
------------------

1. Implemente el analizador léxico para COOL y su dialecto CHILERO en el archivo `lexer-chilero/src/main/jflex/simpletokenizer.lex`.
2. En la última sección de este archivo debera redactar una explicación clara de su solución en lenguaje académico (formal, en tercera persona, directo). Debera explicar las decisiones de diseño, como implementó el soporte al dialecto, si necesitó estados intermedios en JFlex, explicar por qué su código es correcto y que modificaciones se realizaron sobre `test.cl` para que fuera un programa correcto.  Asi mismo debe comentar el código que considere conveniente en JFlex.
3. En el archivo `lexer-chilero/src/main/java/gt/edu/url/Lexer.java` encontrará una implementación de un método principal que invoca a su lexer e imprime los tokens que se detectan. Esta salida es obligatoria para las siguientes fases del proyecto. Debera escribir su propia versión utilizando PicoCLI tal y como se vio en el laboratorio. Esta versión también debera soportar análisis individual de Tokens.
4. El día de la entrega/calificación su instructor le indicará algunas modificaciones con pruebas adicionales (programas en español, ejecuciones de lexer en línea de comandos). El cual usted debera aceptar para comprobar el análisis de su solución.

Note que el autograder proporcionado con este repositorio incluye únicamente pruebas sobre stack y factorial

Instrucciones de uso del makefile
---------------------------------

El archivo Makefile incluido en su repositorio presenta algunas tareas útiles que pueden ser invocadas directamente en la línea de comandos.

Para compilar su programa ejecute

> make compile

Para generar un script `lexer` que ejecute su analizador léxico, ejecute

> make lexer

Para limpiar todo el proyecto ejecute:

> make clean

Así mismo existen dos fases adicionales que ejecutan en secuencia varios pasos para una prueba completa de su solución.

La primera es `make dofactorial` la cual limpia su proyecto, ejecuta la compilación, genera el lexer y ejecuta una prueba del programa `factloop.cl`.

La segunda es `make dostack` la cual limpia su proyecto, ejecuta la compilación, genera el lexer y ejecuta una prueba del programa `stack.cl`.

Si cree que su analizador léxico es correcto, puede ejecutar `mycoolc` el cual une SU analizador léxico con, los analizadores sintácticos, semánticos, generador de código y optimizador de cool. 

Si su analizador léxico se comporta de una manera inesperada, puede obtener errores en cualquier lugar, es decir, durante análisis sintáctico, durante el análisis semántico, durante la generación de código o solo cuando ejecuta el código producido en spim. 

¡Éxitos!

Redacción para primera fase
---------------------------
Como primera fase para el proyecto del curso de compiladores de la Universidad Rafael Landívar en el segundo ciclo del año 2023 se tenía como objetivo el
implementar un analizador léxico que fuese compatible con la gramática del lenguaje de programación COOL (Classroom Object Oriented Language) y
el dialecto CHILERO.

### Pasos en la resolución de la primera fase del proyecto

#### 1. Modificación del archivo POM.xml
Dentro de la carpeta de ~/lexer-chilero se encontraba el archivo pom.xml, al cual se le agregaron los plugins que serían
de ayuda para trabajar con la libreria de Jflex. Dentro del mismo se agregó el plugin que permitió generar un archivo jar
con dependencias "<descritorRef>jar-with-dependencies</descritorRef>" el cual sería de ayuda para armar ejecutable del archivo que se
encuentra en la carpeta /lexer-chilero/src/main/java/gt.edu.url/compiler/Lexer.java, el cual realizaba la lectura de los archivos.

Durante dicha modificación del POM.xml se comentieron pequeños errores en el cierre de las etiquetas de los plugins, lo cual causaba
que al tratar de construir el proyecto no se tomaran las prioridades adecuadas y dicho proceso siempre quedaba a la mitad y 
el compilador lanzaba un error. Luego de arreglar dicho error ya se puedo proceder con el armado del proyecto completo.

#### 2. Modificacion del archivo SimpleTokenizer.lex
Dentro del archivo simpletokenizer.lex el cual se encuentra en la siguiente ruta: lexer-chilero/src/main/jflex/simpletokenizer.lex se procedió
a la generación de las palabras reservadas utilizando macros por su simplicidad, símbolos, operadores, identificadores, números y letras,
todos tomando como base el archivo "TokenConstants.java" ubicado en lexer-chilero/src/main/java/gt/edu/url/TokenConstants.java.

Tomando en cuenta que el estado de YYINITIAL es el estado inicial, se generaron dos estados "CADENAS" que esté sería el encargado de gestionar los errores, cambios
de caracteres, y concatenaciones de cadenas, también el  estado "COMENTARIOLARGO", el cual se implementó para el manejo de comentarios largos y cortos dentro del
lenguaje COOL se pueden generar comentarios largos con el simbolo de "(\*..*)"
Para el manejo de los errores que podrian ocurrir dentro del lexer se implementaron distintas reglas en el resto del archivo.

1. `stringTooLong` -- Es empleado para comprobar si la cadena de caracteres supera el límite de MAX_STR_CONST
2.  `StringIsNull`  -- Es utilizado para encender la bandera si dentro de la cadena encuentra caracteres que no deberian de ser aceptados por la misma

##### Estado `<YYIINITIAL>`

1. Se declararon todas las palabras reservadas , símbolos que únicamente retornarían sus equivalencias de la clase de TokenConstans
   `{clase}      {return new Symbol(TokenConstants.CLASS);     }`, esto se realizó con la ayuda de las macros anteriormente generadas, las cuales tienen soporte tanto en inglés como en español, también el soporte de letras mayúsculas y minúsculas teniendo la siguiente nomenclatura: ([Ii][Ff]) | ([Ss][Ii])

2. Para agregar los `números`, `Tipoidentificador`, `ObjetoIdentificado`, se tuvo que capturar la cadena que se recibe para almacenarla, tanto el valor, el identificador, y el tipo de dato.
   `{numero}        {AbstractSymbol num = AbstractTable.inttable.addString(yytext());
       return new Symbol(TokenConstants.INT_CONST,num);} ` esta es la forma en la cual se obtiene dicho dato.

3. Dentro del estado inicial se ignoran los comentarios de una línea y los espacios en blanco.

4. `\n` cada vez que se encuentre este símbolo en el estado inicial se debe de aumentar la variable `curr_lineno` en 1, ya que esta será la variable que lleve el conteo de las líneas en la que se encuentra nuestro analizador.

5. `*)` en el estado inicial al momento de encontrar el cierre de un comentario se muestra el error "Unmatched **)"

6. `"` Se redirige al estado de `<CADENAS>` ya que es la transición a dicho estado.

7. `(*` Se redirige al estado de `<COMENTARIOLARGO>` ya que es la transición a dicho estado.

##### Estado `<CADENAS>`

1. `"` Al encontrar este carácter será el inicio del estado `<CADENAS>`, y como primer paso se retorna hacia el estado inicial `<YYINITIAL>` y se comprueba si la longitud de la cadena actual que se está analizando es mayor al número máximo aceptado `MAX_STR_CONST`, si esto es correcto se retorna el `TokenConstans.ERROR`, con el error de `"String constant too long"`, posteriormente se valida con la ayuda de la bandera `!StringIsNull`, si se encuentra dentro del estado se activa por alguna razón, se procederá a colocarla en estado apagado, y se concatena todo lo que se encuentre dentro del `String_buf`, y con esto se almacena dentro del token de `TokenConstants,STR_CONST`

2. `\\f|n|b|t|\"|\\` Para el caso de encontrar cada uno los siguientes caracteres se procede a convertirlos a sus caracteres equivalentes dentro de las cadenas
   Se captura el segundo caracter, como se conoce que el caracter anterior a este es `"\"` entonces el siguiente se asume que será cualquiera de estos caracteres `f|n|b|t|"|\`
   Por ejemplo para el caso de encontrar el caracter `f`, se adjunta el caracter `\f` en el `string_buf`
   Se realiza con todos los caracteres posibles y si no coincide simplemente se continua con la lectura del resto de caracteres.

3. `\0` Al encontrar el caracter nulo, se activa la bandera de `StringIsNull` y se retorna el token de error `"String contains null characters"`

4. `{caracteres}+|{whitespace}+` Se procede a juntar los caracteres que encuentren dentro de la cadena, igual que los espacios en blanco.

5. `\n` Estando en el estado de Cadena, al encontrar el salto de linea se suma 1 en la variable de `curr_lineno` , al encontrar el caracter de `'\n'` se adjuta en string `"\n"` a String_buf

6. `n` Si se encuentra únicamente el caracter sin tener una `\ ` que le anteceda, este se regresa al estado inicial, se valida si dentro de la cadena existen caracteres nulos con la bandera y de ser correcto, se retorna el token de error con `Unterminated string constant`

##### Estado `<COMENTARIOLARGO>`

1. `\n` Se suma 1 en la variable curr_lineno porque si dentro del comentario hay un salto de línea es un comentario de múltiples líneas.

2. `.` Si se encuentra cualquier caracter dentro del comentario, se debe de ignorar.

3. `*)` Al encontrar el símbolo de cierre del comentario regresa al estado inicial para continuar con el lexer.

4. `{whitespace}+` Se ignoran los espacios dentro del comentario.

5. `.       {return new Symbol(TokenConstants.ERROR, yytext());}` Cualquier caracter que encuentre fuera de los estados es tomado como un error.

#### 3. Manejo de estados intermedios en el arhivo .lex
Para poder manejar de manera correcta los strings y los errores que involucran EOF la mejor forma es haciendo uso de estados intermedios.
Para la presente implementación se crearon dos estados tanto para cadenas como para comentario largo. En el caso concreto de los strings se utiliza un estadoo debido a las
diferentes combinaciones que pueden ocurrir dentro de una cadena en COOL, como el manejo de caracteres \t y los errores del caracter nulo, salto de
linea indivual o múltiple y longitud máxima de una cadena.

#### 4. Modificacion del archivo SimpleTokenizer.lex (Extensión del archivo)
Para hacer más fácil la lectura y trabajo de todo el código dentro del archivo simpletokenizer.lex se procedió a cambiar la extensión de dicho archivo
por .flex y poder utilizar la extensión del IDE IntelliJ. Por esa razón dicho archivo aparece como "simpletokenizer.flex"

#### 5. Modificación del archivo Lexer.java
Se realizaron cambios para la lectura de archivos haciendo uso de la implementacion de PICOCLI con lo cual se facilitó el uso de la terminal para el
análisis de tokens de forma individual al momento que se ingresen dentro de la terminal.

#### 6. Ejecución, construcción y revisión del proyecto conjuto a arreglo de errores
Para poder proceder con el proyecto y la búsqueda de errores en los archivos indicados por el catedrático del curso se tenía que poder armar primero
un ejecutable del presente código. A continuación se enlistan el orden de los comandos que fueron ejecutados en la terminal del IDE:

    1. make compile: Con este comando se compila la solución completa. Dicho comando se ejecutó sin errores.
    2. make lexer: Con este comando se genera un script para ejecutar el analizador léxico previamente trabajado.

Luego de haber ejecutado los comando de Make se procedió con la ejecución de los siguientes comandos:

    1. bin/lexer cooltests/factloop.cl cooltests/atoi.cl --> Con este comando se ejecutan las pruebas para el factloop haciendo uso de atoi.cl
        1.1 El resultado anteriormente obtenido también puede lograrse con el siguiente comando: make dofactorial
    2. bin/lexer cooltests/stack.cl cooltests/atoi.cl --> Con este comando se ejecutan las pruebas para el stack haciendo uso de atoi.cl
        2.1 El resultado anteriormente obtenido también puede lograrse con el siguiente comando: make dostack

Cabe mencionar que en los pasos anteriormente descritos ambas parejas de comandos deben de funcionar sin problemas y se deben de obtener los mismos resultados
en la lectura de tokens, con esto se comprueba que el analizador léxico está correctamente escrito.

Para continuar, se procedió a correr el siguiente comando:

    1. bin/lexer cooltests/test.cl cooltests/atoi.cl --> Con este comando se ejecutan las pruebas del arhivo test.cl haciendo uso de atoi.cl

Al ejecutar el comando descrito arriba se encontraron errores en la lectura de tokens, dichos errores fueron los siguientes:

#56 ERROR "'"
--> '.'
El error fue el uso de las comillas simples para tomar el dato como una cadena, pero no son reconocidas dentro del lenguaje de COOL.

#62 ERROR "["
#62 ERROR "]"
--> (let num : Int <- num_cells[] in
Se encontraron los símbolos "[]" los cuales denotan un arreglo pero este simbolo no es correcto en COOL y posteriormente de num_cells que es una declaración de un método Int

#86 ERROR ">"
--> while countdown > 0 loop
Dentro del lenguaje COOL según su documentación se sabe que únicamente cuenta con tres símbolos de comparacion <, <=, =. por lo que el símbolo > no es reconocido por el lenguaje.

#98 ERROR "EOF in comment"
--> );  (* end let countdown
Dentro del lenguaje se tiene definido que un comentario largo debe de tener apertura y cierre, pero este solo tenía apertura "(*"


Es importante mencionar que la forma en que se colocaron los errores de arriba fue primero el error mostrado en la terminal y luego la línea o líneas de código del archivo test.cl
donde se encontraban dichos errores y una breve descripción.

Como parte de este paso, se procedió con la corrección de dichos errores, y las soluciones fueron las siguientes:

#56 ERROR "'"
* Se cambiaron las comillas simples '' por comillar dobles ""

#62 ERROR "["
#62 ERROR "]"
* Se cambiaron los corchetes [] por paréntesis ()

#86 ERROR ">"
* Se cambió el orden en el que estaba definida la validación del ciclo while para voltear el símbolo de comparación y hacerlo válido

#98 ERROR "EOF in comment"
* No se tenía el cierre del comentario largo, entonces se procedió a cerrarlo con el símbolo "*)" en la misma línea.


Luego de arreglar los errores anteriormente descritos se procedió a correr el comando: ./mycoolc cooltests/test.cl con el cual se obtuvieron los siguientes errores:

"cooltests/test.cl", line 92: syntax error at or near POOL --> Error generado por una llave de cierre faltante.
"cooltests/test.cl", line 96: syntax error at or near '}'  --> Error generado por una llave de cierre faltante.
Compilation halted due to lex and parse errors

Los errores anteriormente descritos se arreglaban ambos colocando una llave de cierre antes de POOL...

countdown <- countdown - 1;
**FALTA CIERRE DE LLAVE**                   
pool

Luego de haber arreglado dicho error se procedió de nuevo a correr el comando ./mycoolc cooltests/test.cl
Esta vez funcionó de forma correcta mostrando una siguiente línea de comandos lista para escribir.
Para finalizar se ejecutó el comando ./bin/spim cooltests/test.s y se obtuvo el siguiente resultado:

<br>SPIM Version 6.5 of January 4, 2003
<br>Copyright 1990-2003 by James R. Larus (larus@cs.wisc.edu).
<br>All Rights Reserved.
<br>See the file README for a full copyright notice.
<br>Loaded: ../lib/trap.handler<br>
<br>**(Salida generada en forma de un pino)**<br>
<br>COOL program successfully executed

Luego de haber realizado todas las correcciones necesarias en el archivo test.cl se logra genera un archivo test.s con el cual ya se obtiene
una ejecución y compilación exitosa del programa completo.

---------------------------

Fase 01 del proyecto de compiladores - Completa ✅