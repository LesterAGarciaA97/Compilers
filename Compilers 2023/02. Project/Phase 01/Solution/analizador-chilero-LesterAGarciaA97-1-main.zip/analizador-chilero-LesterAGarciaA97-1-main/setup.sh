#!/bin/bash
sudo apt-get install -y libxaw7-dev libc6-i386
