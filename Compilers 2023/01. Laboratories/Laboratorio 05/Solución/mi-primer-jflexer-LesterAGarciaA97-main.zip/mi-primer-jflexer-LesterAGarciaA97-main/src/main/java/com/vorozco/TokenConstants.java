package com.vorozco;

public enum TokenConstants {
    ID,
    NUM,
    REAL,
    KEYWORD,
    COMMENT,
    DOMAIN,
    EMAIL,
    PHONE,
    EOF
}
