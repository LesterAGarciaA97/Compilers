package gt.url.edu;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
        //var textoVersionJava1 = "mi version es 17";
        //var textoVersionJava2 = "mi version es version de Java instalada en el sistema"
        //var textoVersionJava = "mi version de Java instalada en el sistema es ";
        var textoVersionJava = "mi version es ";
        var versionJava = System.getProperty("java.version");

        System.out.println(textoVersionJava + versionJava);
    }
}