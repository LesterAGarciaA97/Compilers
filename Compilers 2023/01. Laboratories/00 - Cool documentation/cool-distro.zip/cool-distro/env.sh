#!/bin/bash
actualpath=$PWD/bin
echo $actualpath
export PATH=$actualpath:$PATH
echo $PATH
