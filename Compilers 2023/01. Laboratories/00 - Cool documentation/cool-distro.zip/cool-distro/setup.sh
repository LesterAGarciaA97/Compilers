#!/bin/bash
sudo apt-get install -y flex bison build-essential csh openjdk-8-jdk libxaw7-dev libc6-i386
