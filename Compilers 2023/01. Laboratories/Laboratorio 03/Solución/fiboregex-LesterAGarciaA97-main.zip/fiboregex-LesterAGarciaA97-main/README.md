[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/qv_rvMAn)
[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=11628273&assignment_repo_type=AssignmentRepo)
Descripción
===========

El objetivo del laboratorio es explorar las consecuencias de una mala
programación.

Laboratorio
===========

El tutor del curso le asignara una tarea via GitHub Classroom, para esta
tarea:

1. Resuelva el laboratorio en SU fork del repositorio, las pruebas
    serán ejecutadas automáticamente. Puede utilizar el IDE que
    considere conveniente siempre que este tenga soporte para JUnit 5 y Java 17


2. Analice el contenido de la clase FraseTest, implemente la clase
    Frase que satisfaga cada uno de los tests presentados


3. La clase FibonacciCreator presenta una implementación que es capaz
    de calcular el n-esimo termino de la sucesión de Fibonacci
    (iniciando la cuenta en 0), la cual es dada por la siguiente
    progresión:

    > número 0 - 0, número 1 - 1, número 2 - 0+1=1, número 3 - 1+1=2,
    número 4 - 1+2=3, número 5 - 2+3=5, número 6 - 8 = 5+3
    
    En el repositorio base implementado para este proyecto, usted
    también encontrara la clase FibonacciTest, que podría (o no) ser
    funcional al momento que usted trabaje sobre su copia. Corrija la
    implementación de tal forma que los tests sean funcionales.

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

4. ¿Que cambios ha realizado? ¿Por qué? Explique su respuesta y adjuntela en su archivo README.md

   ## Cambios realizados en Clase Frase.java para la solución de los 4 métodos relacionados a las frases (doPaco, doReversa, doPalindromo y doMayusculas)

1) doPaco: En esta lo que hice fue crear una variable que tuviera el valor literal "juan paco pedro de la mar" y luego retorno esa variable.

2) doFraseREversa: Aquí creé una variable llamada fraseReversa en la cual almacenaría la frase con su nuevo orden, le hice un split para identificar hasta donde llegaba cada palabra viendo los espacios en blanco (espacios intermedios entre palabras), después recorrí el tamaño completo de la cadena y que lo fuera restando, a diferencia de un for normal, en este lo restaba, y por último validaba si debía tener o no un espacio entre cada palabra para mostrar el nuevo orden de las palabras con sus respectivos espacios.

3) doPalindromo: Aquí primero pasé todo a minúsculas y reemplazé todos los espacios en blanco para dejar todo junto. Luego en un arreglo de caracteres fui ingresando letra por letra al arreglo, después en un ciclo for recorrí todo el arreglo y verificaba la última letra con la primera, si eran iguales es palíndromo y sino no lo es.

4) doMayusculas: En este puse como valor definido "paco" a una variable la cual mientras recorro un ciclo for, valido con un if si es diferente o no a la posición del arreglo, si es diferente la mete al arreglo, si es igual la elimina, esto lo logré impelmentando un .split y luego pasé todo a mayúsculas y regresé el nuevo arreglo ya sin la palabra paco en él.

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

   ## Cambios realizados en Clase FibonacciCreator.java

Incialmente se tenía una doble recursividad al tener un If dentro de otro, el cual causaba un número ilimitado de iteraciones lo que terminaba en un timeout y no se obtenía la respuesta esperada.

Para lograr ejecutar el Thanos Fibonacci y evitar la doble recursividad primero creé un punto final para la recursividad, asegurándome de que cuando la variable con valor entero sea menor a 1, la función devuelva NULL. Con esto logré evitar el ciclo infinito o uso desmedido de recursos en mi máquina virtual.

Después les asigné valores iniciales de 0 y 1 a las primeras dos posiciones de la secuencia de Fibonacci ya que dicha secuencia inicia con 0 y 1 consecutivamente. En lugar de utilizar recursividad doble, donde cada llamada de la función genera dos llamadas extras, lo cambié por un ciclo while para ir sumando y restando a los valores predefinidos de 0 y 1 para generar el resto de los dígitos de la secuencia después de los valores iniciales.
