package com.vorozco;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PopolTest {

    Popol popol;

    @BeforeEach
    public void init(){
        popol = new Popol();
    }
    @Test
    public void huhahpu() throws Exception {
        assertEquals("e", popol.cuentaHunahpuRegex().get(2));
        assertEquals("resuena", popol.cuentaHunahpuRegex().get(5));
    }

    @Test
    public void ixbalanque() throws Exception {
        assertEquals("conocidos", popol.cuentaIxbalanqueRegex().get(1));
        assertEquals("encapsula", popol.cuentaIxbalanqueRegex().get(3));
    }
}
