package com.vorozco;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Popol {
    public List<String> cuentaHunahpuRegex() throws IOException {
        //Expresiòn regular con el código u00FA el cual es equivalente a ú pero para servidores Linux como el del autocalificador
        String regex = "(((?<=Hunahp\u00FA\\s)|(?<=Hunahp\u00FA\\\"\\s)|(?<=Hunahp\u00FA,\\s)))[[a-z][A-Z][\\d]]*";
        return findMatches(regex);
    }
    public List<String> cuentaIxbalanqueRegex() throws IOException {
        String regex = "(([[a-z][A-Z][\\d]]*(?<=Ixbalanque,)|(?<=Ixbalanque\\\"\\s)|(?<=Ixbalanque\\s)|(?<=Ixbalanque,+\\s)))[[a-z][A-Z][\\d]]*";
        return findMatches(regex);
    }
    //Método para que después de encontrar todos las posibles coincidencias con el Regex los meta en un arreglo
    private List<String> findMatches(String regex) throws IOException {
        List<String> occurrences = new ArrayList<>();
        //Se instancia la lectura del archivo desde el Path del proyecto
        String resourceFile = "popolvuh.txt";

        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(resourceFile);
             //Aquì es importante colocar que para el BufferedReader se le envíe el charset tipo UTF-8 para que tanto los test locales como en el autocalificador funcionen y reconozcan el Unicode que se colocó de la ú
             BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream,"UTF-8"))) {
            StringBuilder fileContent = new StringBuilder();
            String content;
            //Lectura línea línea del archivo popolvuh.txt
            while ((content = reader.readLine()) != null) {
                fileContent.append(content).append("\n");
            }
            //Búsqueda de concidencias evaluadas con base al regex armado anteriormente
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(fileContent.toString());

            while (matcher.find()) {
                //EN este caseo dentro del paréntesis se puede colocar el valor que coincida del primer grupo o de n grupo, pero como es un List, no se necesita para este caso.
                occurrences.add(matcher.group());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return occurrences;
    }
}