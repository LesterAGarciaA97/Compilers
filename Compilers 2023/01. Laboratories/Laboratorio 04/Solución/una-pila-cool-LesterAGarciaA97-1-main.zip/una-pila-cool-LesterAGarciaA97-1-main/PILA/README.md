Archivo README para el laboratorio PILA
=======================================

Su directorio ahora debería contener los siguientes archivos:

* Makefile
* README
* atoi.cl
* pila.cl
* pila.test

El Makefile contiene objetivos para compilar y ejecutar su programa, así como entregarlo.

El README contiene esta información. Parte de la tarea es responda las preguntas al final de este archivo README. Edite este archivo en formato [Markdown](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet)

atoi.cl es una implementación en Cool de la función de conversión cadena a entero conocida del lenguaje C.

pila.cl es el archivo esqueleto con el que debe completar su programa

pila.test es una breve entrada de prueba a la máquina de pila.

Instrucciones
------------

Para compilar y ejecutar su programa, escriba:

> make test

Sin hacer ningún cambio el programa debe imprimir "Nothing implemented"


Para simplemente compilar su programa, escriba

> make compile


Las instrucciones para entregar la tarea se publicarán en Moodle.

¡BUENA SUERTE!


Preguntas sobre LAB PILA
------------------------

</br>

1. Describa su implementación de la máquina de pila en un párrafo.

Para mi implementación de una máquina de pila, tuve la idea de manejar una 
cadena como una pila. Entrando un poco màs en detalle consideré cómo una lista podría representar un string,
cada letra se consideraba como una posición, y la estructura de pila entrarìa en funcionamiento al procesar la
cadena de texto de atrás hacia adelante.

Ahora en cuanto a los métodos que se utilizarían durante la ejecución los cuales eran "+" "s" y "d" realicé lo siguiente:

1.1 e: Este método al momento de evaluar la pila analizaba el valor que se encontraba al principio de la pila, de esta manera se retornada la cabeza de la pila, para esto usé un substr que devolviera el valor que estaba en la parte supeior y luego entraba a una sentencia if dodne validé lo siguiente:

1.1.1 Si el simbolo era "+" se saca este simbolo de la pila y luego los dos enteros que venía después se sumaban, est lo logré utilizando variables auxiliares como pivotes para leer los valores dentro de la estructura y luego pasarlos a tipo entero con la ayuda de ATOI.CL y se realizara la suma, por ejemplo tenía un 3, ya luego ese 3 tipo entero lo convertía a tipo String y lo metía de nuevo a la estructura.

1.1.2 Si el simbolo era "s" hacía un cambio de posición de todos aquellos valroes que venían después de la letra "S" , para esto usé una variable como pivote que me permitira obtener los valores, ya que después de obtenerlos realizaba el intercambio entre sus posiciones, y se agregaban a la pila.

1.1.3 Por ultimo si el valor de esa posición era un número entero, solamente lo agregaba en el tope de la pila, en mi caso, hasta arriba de la cadena.

1.2 d: Con este valor mostraba todos los valores actuales que estaban dentro de la pila, cada uno de los valores que esta contenga en ese momento, y esto lo hice con un cilco ciclo While que iniciaba como verdadero hasta que una variable contador fuera diferente de 0.

1.3 x: Este  carácter termina el programa, tengo validado que al recibir una "x" acaba la ejecución.

</br>

2. Escriba una lista de tres características del lenguaje cool (-e.g. soporta programación orientada a objetos-).

* Es un lenguaje fuertemente tipado
* Asignación dinámica
* Manejo automático de memoria
* La herencia de las clases permite realizar implementaciones más sencillas de codigo.

</br>

3. Escriba una lista de tres características que crea que pueden mejorar en COOL.

* El uso de ; debería de ser en todas las líneas porque llega a ser confuso en cual línea cerrar con ; y en cuales no.
* El cierre de palabras reservadas como loop con pool o if con fi pienso que podría cambiarse y trabajar como un lenguaje de programación común.
* El uso del símbolo <- podría estandarizarse a un símbolo = ya que don esto nos abrìría la posibilidad a trabajar con comparadores <> y sus combinaciones con el =