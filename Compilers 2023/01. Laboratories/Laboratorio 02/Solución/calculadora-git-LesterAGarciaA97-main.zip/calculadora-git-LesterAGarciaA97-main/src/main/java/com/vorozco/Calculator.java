package com.vorozco;

//Implementando clase Calculator para poder satisfacer los mètodos utilizados en el mètodo main
public class Calculator {
    //Solución de la operación suma en una rama llamada suma
    public int add(int Num1, int NUm2){
        var totalSum = Num1 + NUm2;
        return totalSum;
    }
    //Solución de la operación resta  en una rama llamada resta
    public int subtract(int Num1, int Num2) {
        var totalSubtract = Num1 - Num2;
        return totalSubtract;
    }
    //Solución de la operación multiplicacion  en una rama llamada multiplicacion
    public int multiply(int Num1, int Num2) {
        var totalMultiply = Num1 * Num2;
        return totalMultiply;
    }
    //Solución de la operación división  en una rama llamada división
    public int divide(int Num1, int Num2) {
        var totalDivide = Num1/Num2;
        if (Num2 == 0){
            System.out.println("División entre 0 no permitida. SYNTAX ERROR");
        }
        else{
            System.out.println("El resultado de la división es: " + totalDivide );
        }
        return totalDivide;
    }
}
